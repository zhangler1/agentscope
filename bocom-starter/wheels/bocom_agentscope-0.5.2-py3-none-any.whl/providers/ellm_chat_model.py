# -*- coding: utf-8 -*-
"""The ELLM chat model implementation (BOCOM adapter).

The BOCOM ELLM (Enterprise Large Language Model) gateway exposes an
OpenAI-compatible ``/chat/completions`` endpoint with two protocol
differences handled by this class:

- Streaming responses do not wrap their reasoning in ``<think>`` tags;
  when :attr:`inject_think_tag` is enabled the tag is prepended to the
  first non-empty text delta.
- The generation cap must be sent under the ``max_tokens`` field name
  (the adapter rejects ``max_completion_tokens``).

The key-refresh logic (api-key header rotation) lives in the
:class:`~providers.middleware.ellm_refresh.EllmKeyRefreshMiddleware`,
which injects the fresh key per call via :meth:`set_api_key`; this class
only carries the protocol differences.

``inject_think_tag`` is decided at construction time by the caller.
``context_size`` is optional: when omitted it is resolved from the model card
matching the requested model name — the service-mode factory
(:func:`agentscope.app._service._model.get_model`) builds models from the
session's ``ChatModelConfig`` only, which has no ``context_size`` field — and
falls back to :data:`_DEFAULT_CONTEXT_SIZE` when no card matches.

The model cards live **outside this package**: the serving application points
at their directory once at startup via :meth:`EllmChatModel.set_models_dir`.
``list_models`` serves the same cards to the frontend, so the candidate list
and the runtime ``context_size`` always read one source.  No Redis is
consulted anywhere in this module.
"""
import os
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import (
    Any,
    AsyncGenerator,
    Awaitable,
    Callable,
    List,
    Literal,
    TYPE_CHECKING,
    Type,
)

import openai
from pydantic import BaseModel, Field

# 与 SDK 共用同一个 logger（名为 "as"）：日志格式、级别、handler 均与
# agentscope 内部一致，由 ``agentscope.setup_logger`` 统一控制。
from agentscope import logger
from agentscope._utils._common import _generate_id
from agentscope.formatter import DeepSeekChatFormatter, FormatterBase
from agentscope.message import Msg, TextBlock, ThinkingBlock, ToolCallBlock
from agentscope.model import ModelCard
from agentscope.model._base import ChatModelBase, _TOOL_CHOICE_LITERAL_MODES
from agentscope.model._model_response import ChatResponse
from agentscope.model._model_usage import ChatUsage
from agentscope.tool import ToolChoice

_DEFAULT_CONTEXT_SIZE = 32768
"""Context window used when the configured model cards carry no card that
matches the requested model name.

Mirrors the :class:`~agentscope.model.ChatModelBase` default so a mistyped or
not-yet-carded model name degrades to the framework default instead of
failing to construct.  A *missing or unconfigured card directory* is a
configuration error and raises instead — see :meth:`EllmChatModel.
set_models_dir`.
"""

if TYPE_CHECKING:
    from providers.credential import ELLMCredential
    from openai.types.chat import ChatCompletion
    from openai import AsyncStream
else:
    ChatCompletion = Any
    AsyncStream = Any


class EllmChatModel(ChatModelBase):
    """The ELLM chat model."""

    type: Literal["ellm_chat"] = "ellm_chat"
    """The type of the chat model."""

    inject_think_tag: bool = False
    """Whether to prepend a ``<think>`` tag to the first non-empty text
    delta of streaming responses. Set from the ``inject_think_tag``
    ``__init__`` parameter; the key-refresh middleware may still
    override the attribute per call."""

    _models_dir: str | None = None
    """Directory holding the ``*.yaml`` model cards, set once by the serving
    application via :meth:`set_models_dir` before the app starts.

    It has to live on the class rather than on an instance or a request:
    ``GET /model/`` resolves candidates through the *classmethod*
    :meth:`list_models` (see ``agentscope.app._router._model``), where no
    credential instance exists.  Both that route and the runtime model
    construction go through this same class, so one class-level setting is
    enough for the candidate list and ``context_size`` to agree."""

    class Parameters(BaseModel):
        """The parameters for the ELLM chat model."""

        max_tokens: int | None = Field(
            default=None,
            title="Max Tokens",
            description="The maximum number of tokens for the LLM output.",
            gt=0,
        )

        temperature: float | None = Field(
            default=None,
            title="Temperature",
            description="The temperature for the LLM output.",
            ge=0,
            le=2,
        )

        top_p: float | None = Field(
            default=None,
            title="Top P",
            description="The top P value for the LLM output.",
            gt=0,
            le=1,
        )

        enable_thinking: bool | None = Field(
            default=None,
            title="Enable Thinking",
            description=(
                "Whether to enable the model's thinking mode, sent as "
                "``chat_template_kwargs.enable_thinking``. None = no override."
            ),
        )

        reasoning_effort: str | None = Field(
            default=None,
            title="Reasoning Effort",
            description=(
                "Reasoning effort hint (e.g. 'low'/'medium'/'high'), sent "
                "as the top-level ``reasoning_effort`` request field. "
                "None = no override."
            ),
        )

    @classmethod
    def set_models_dir(cls, path: str | os.PathLike[str] | None) -> None:
        """Point model-card loading at ``path``.

        Called once by the serving application at startup, before the app
        starts serving.  It replaces the SDK default (``<package>/_models``,
        which is not shipped here) for every consumer of this class.

        Absolute and relative paths are both accepted; a relative path is
        resolved against the *current working directory*, so prefer passing
        an absolute one (e.g. built from ``__file__``) when the working
        directory is not guaranteed.

        Args:
            path (`str | os.PathLike[str] | None`):
                Directory holding the ``*.yaml`` model cards.  ``None``
                clears the setting again (tests / embedded use); subsequent
                card lookups then fail with a configuration error.

        Raises:
            FileNotFoundError:
                When ``path`` does not exist or is not a directory.  The
                directory is a deployment artifact, so a missing one is a
                configuration error and must stop the service at startup
                instead of degrading to an empty candidate list.
        """
        if path is None:
            cls._models_dir = None
            return

        resolved = Path(path).expanduser().resolve()
        if not resolved.is_dir():
            raise FileNotFoundError(
                f"ELLM model cards directory not found: {resolved}. "
                "Create it (with the model card *.yaml files) or point "
                "EllmChatModel.set_models_dir() at an existing directory.",
            )
        cls._models_dir = str(resolved)
        logger.info("ELLM model cards directory: %s", cls._models_dir)

    @classmethod
    def _resolve_models_dir(cls) -> str:
        """Return the configured card directory.

        Returns:
            `str`:
                The directory set by :meth:`set_models_dir`.

        Raises:
            RuntimeError:
                When no directory has been configured.  Failing loudly beats
                silently returning an empty candidate list and silently
                compressing context with :data:`_DEFAULT_CONTEXT_SIZE`.
        """
        if not cls._models_dir:
            raise RuntimeError(
                "ELLM model cards directory is not configured. Call "
                "EllmChatModel.set_models_dir(<dir>) at startup.",
            )
        return cls._models_dir

    @classmethod
    def list_models(
        cls,
        custom_yaml_dir: str | None = None,
    ) -> list[ModelCard]:
        """List the ELLM candidate model cards.

        Signature mirrors :meth:`agentscope.model.ChatModelBase.list_models`
        so the framework's zero-argument call sites (``GET /model/``) and
        :meth:`agentscope.credential.CredentialBase.list_models` keep working.

        Args:
            custom_yaml_dir (`str | None`, optional):
                Explicit override, highest priority.  Defaults to the
                directory configured via :meth:`set_models_dir`.

        Returns:
            `list[ModelCard]`:
                The candidate models described by the card files.

        Raises:
            FileNotFoundError:
                When the effective directory does not exist.
            RuntimeError:
                When neither ``custom_yaml_dir`` nor :meth:`set_models_dir`
                was provided.
        """
        if custom_yaml_dir is not None:
            resolved = Path(custom_yaml_dir).expanduser().resolve()
            if not resolved.is_dir():
                raise FileNotFoundError(
                    f"ELLM model cards directory not found: {resolved}.",
                )
            return super().list_models(custom_yaml_dir=str(resolved))

        return super().list_models(custom_yaml_dir=cls._resolve_models_dir())

    @classmethod
    def _resolve_context_size(cls, model: str) -> int:
        """Resolve ``model``'s context window from its model card.

        ``context_size`` cannot come from the caller on the service path:
        :func:`agentscope.app._service._model.get_model` builds every chat
        model from the session's ``ChatModelConfig``, which carries only
        ``type`` / ``credential_id`` / ``model`` / ``parameters``.  The model
        cards — the same ones :meth:`list_models` serves to the frontend —
        hold the value instead.

        A *missing card directory* propagates from :meth:`list_models` as a
        configuration error on purpose; only a model name that has no card is
        tolerated here.

        Args:
            model (`str`):
                The model name to look up.

        Returns:
            `int`:
                The matching card's ``context_size``, or
                :data:`_DEFAULT_CONTEXT_SIZE` when no card matches.
        """
        for card in cls.list_models():
            if card.name == model:
                return card.context_size
        logger.warning(
            "No ELLM model card found for %r in %s; falling back to "
            "context_size=%d",
            model,
            cls._models_dir,
            _DEFAULT_CONTEXT_SIZE,
        )
        return _DEFAULT_CONTEXT_SIZE

    def __init__(
        self,
        credential: "ELLMCredential",
        model: str,
        context_size: int | None = None,
        parameters: "EllmChatModel.Parameters | None" = None,
        stream: bool = True,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        inject_think_tag: bool = False,
        formatter: FormatterBase | None = None,
        client_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the ELLM chat model.

        Args:
            credential (`ELLMCredential`):
                The BOCOM ELLM credential used to authenticate API calls.
            model (`str`):
                The ELLM model name, e.g. ``Qwen3-235B-A22B``.
            context_size (`int | None`, defaults to `None`):
                The model context size used for context compression. When
                ``None`` (the service-mode path, where the framework does not
                pass it) it is resolved from the model card matching
                ``model`` in the directory configured via
                :meth:`set_models_dir`, falling back to
                :data:`_DEFAULT_CONTEXT_SIZE` when no card matches.
            parameters (`EllmChatModel.Parameters | None`, defaults to \
            `None`):
                The ELLM API parameters. When ``None``, the default
                parameters will be used.
            stream (`bool`, defaults to `True`):
                Whether to enable streaming output.
            max_retries (`int`, defaults to `3`):
                The maximum number of retries for the ELLM API.
            retry_delay (`float`, defaults to `1.0`):
                Seconds to sleep between retry attempts.
            inject_think_tag (`bool`, defaults to `False`):
                Whether to prepend a ``<think>`` tag to the first non-empty
                text delta of streaming responses.
            formatter (`FormatterBase | None`, defaults to `None`):
                The formatter that converts ``Msg`` objects to the format
                required by the ELLM API. When ``None``, a
                ``DeepSeekChatFormatter`` instance will be used.
            client_kwargs (`dict[str, Any] | None`, defaults to `None`):
                Extra keyword arguments forwarded to ``openai.AsyncClient``
                (e.g. ``timeout``, ``default_headers``, ``http_client``).
        """
        if context_size is None:
            context_size = self._resolve_context_size(model)

        super().__init__(
            credential=credential,
            model=model,
            parameters=parameters or self.Parameters(),
            stream=stream,
            max_retries=max_retries,
            retry_delay=retry_delay,
            context_size=context_size,
        )
        self.inject_think_tag = inject_think_tag
        self.formatter = formatter or DeepSeekChatFormatter()
        self.client_kwargs = client_kwargs or {}
        # Request-level api key override, injected per call by the
        # ``EllmKeyRefreshMiddleware``.  When unset, the static
        # ``credential.api_key`` configured at construction time is used.
        self._api_key_override: str | None = None
        # Callback invoked when a 401-triggered forced key refresh fails:
        # it forcibly marks the credential's stored key as expired so the
        # *next* conversation using this credential refreshes it lazily.
        # Injected per call by the ``EllmKeyRefreshMiddleware`` (bound to
        # the current credential); when ``None`` (e.g. the model is called
        # outside the middleware) a failed refresh is surfaced as-is.
        self._auth_invalidate_callback: (
            Callable[[], Awaitable[None]] | None
        ) = None

        # Callback invoked when the gateway rejects our key with an
        # ``invalid_api_key`` 401.  It must force-fetch a fresh key
        # (lock-protected) and return it so the current call can be
        # retried once.  Injected per call by the ``EllmKeyRefreshMiddleware``;
        # when ``None`` (e.g. the model is called outside the middleware) a
        # 401 is surfaced as-is without refreshing/retrying.
        self._refresh_key_callback: (
            Callable[[], Awaitable[str]] | None
        ) = None

        self.client: openai.AsyncClient = openai.AsyncClient(
            api_key=self.credential.api_key.get_secret_value(),
            base_url=self.credential.base_url,
            **self.client_kwargs,
        )

    def set_api_key(self, api_key: str) -> None:
        """Set the request-level API key override for subsequent calls.

        Used by :class:`~providers.middleware.ellm_refresh.
        EllmKeyRefreshMiddleware` to inject a freshly-refreshed key before
        each model call without recreating the client.  When unset, the
        static ``credential.api_key`` configured at construction time is
        used.

        Args:
            api_key (`str`):
                The API key to send as ``Authorization: Bearer <api_key>``.
        """
        self._api_key_override = api_key

    def set_auth_invalidate_callback(
        self,
        callback: Callable[[], Awaitable[None]] | None,
    ) -> None:
        """Set (or clear) the refresh-failure invalidation callback.

        The callback is invoked when a 401-triggered forced key refresh
        fails; it should forcibly expire the underlying credential so the
        next call using it refreshes the key.  It is injected per call by
        the
        :class:`~providers.middleware.ellm_refresh.EllmKeyRefreshMiddleware`
        and is bound to the credential actually in use for this call.

        Args:
            callback (`Callable[[], Awaitable[None]] | None`):
                Async no-arg callback, or ``None`` to disable invalidation.
        """
        self._auth_invalidate_callback = callback

    def set_refresh_key_callback(
        self,
        callback: Callable[[], Awaitable[str]] | None,
    ) -> None:
        """Set (or clear) the forced key-refresh callback.

        The callback is invoked when the gateway rejects our key with an
        ``invalid_api_key`` 401: it must force-fetch a fresh key
        (lock-protected) and return it, so the current call can be retried
        once with the new key.  It is injected per call by the
        :class:`~providers.middleware.ellm_refresh.EllmKeyRefreshMiddleware`
        and is bound to the credential actually in use for this call.

        Args:
            callback (`Callable[[], Awaitable[str]] | None`):
                Async no-arg callback returning a fresh key, or ``None`` to
                disable refresh-and-retry on 401.
        """
        self._refresh_key_callback = callback

    async def aclose(self) -> None:
        """Close the underlying openai client and release its connection pool.

        Used by the summarization middleware after a temporary
        compression-model instance is done (see
        ``providers.middleware.summarization``); session-scoped models
        are recreated per run and do not need this.
        """
        await self.client.close()

    @staticmethod
    def _is_invalid_key_error(exc: Any) -> bool:
        """Whether an exception is a "key missing/expired" 401.

        Different upstream gateways report an invalid/expired API key with
        different payloads, all over HTTP 401:

        - BOCOM ELLM gateway: ``{"error": {"code": "invalid_api_key",
          "message": "API KEY不存在或已过期"}}``;
        - OpenAI / DeepSeek official: ``{"error": {"type":
          "authentication_error", "code": "invalid_request_error",
          "message": "Authentication Fails, Your api key: **** is invalid"}}``.

        We accept any of: ``code == "invalid_api_key"``, ``type ==
        "authentication_error"``, or message keywords (``不存在或已过期`` /
        ``invalid`` / ``authentication``) so a 401 that really means "the key
        is bad" triggers refresh-and-retry across gateways.
        """
        if getattr(exc, "status_code", None) != 401:
            return False
        body = getattr(exc, "body", None)
        if isinstance(body, dict):
            code = str(body.get("code") or "")
            etype = str(body.get("type") or "")
            message = str(body.get("message") or "")
            if code == "invalid_api_key":
                return True
            if etype == "authentication_error":
                return True
            lower = message.lower()
            if "不存在或已过期" in message:
                return True
            if "invalid" in lower or "authentication" in lower:
                return True
        # Fallback: streamed 401 leaves ``body`` empty — scan the exception
        # text instead (e.g. "... Your api key: **** is invalid ...").
        exc_text = str(exc)
        lower = exc_text.lower()
        if "invalid" in lower or "authentication" in lower or "api key" in lower:
            return True
        return False

    @classmethod
    def _get_retryable_exceptions(cls) -> tuple[Type[Exception], ...]:
        return (
            openai.APIConnectionError,
            openai.APITimeoutError,
            openai.RateLimitError,
            openai.InternalServerError,
        )

    async def _call_api(
        self,
        model_name: str,
        messages: list[Msg],
        tools: list[dict] | None = None,
        tool_choice: ToolChoice | None = None,
        **generate_kwargs: Any,
    ) -> ChatResponse | AsyncGenerator[ChatResponse, None]:
        """Call the ELLM chat completions API.

        Args:
            model_name (`str`):
                The model name to use for this call.
            messages (`list`):
                A list of message dicts with ``role`` and ``content`` keys.
            tools (`list[dict]`, default `None`):
                The tools JSON schemas.
            tool_choice (`ToolChoice | None`, optional):
                Controls which (if any) tool is called by the model.
            **generate_kwargs (`Any`):
                Extra keyword arguments forwarded to the API.

        Returns:
            `ChatResponse | AsyncGenerator[ChatResponse, None]`:
                A ``ChatResponse`` when streaming is disabled, or an async
                generator of ``ChatResponse`` objects when streaming is
                enabled.
        """
        formatted_messages = await self.formatter.format(messages)

        kwargs: dict[str, Any] = {
            "model": model_name,
            "messages": formatted_messages,
            "stream": self.stream,
        }

        if self.parameters.max_tokens is not None:
            kwargs["max_tokens"] = self.parameters.max_tokens

        if self.parameters.temperature is not None:
            kwargs["temperature"] = self.parameters.temperature

        if self.parameters.top_p is not None:
            kwargs["top_p"] = self.parameters.top_p

        if self.parameters.enable_thinking is not None:
            extra_body = dict(kwargs.get("extra_body") or {})
            chat_template_kwargs = dict(
                extra_body.get("chat_template_kwargs") or {}
            )
            chat_template_kwargs["enable_thinking"] = (
                self.parameters.enable_thinking
            )
            extra_body["chat_template_kwargs"] = chat_template_kwargs
            kwargs["extra_body"] = extra_body

        if self.parameters.reasoning_effort:
            kwargs["reasoning_effort"] = self.parameters.reasoning_effort

        kwargs.update(generate_kwargs)

        if self._api_key_override:
            headers = dict(kwargs.pop("extra_headers", None) or {})
            headers["Authorization"] = f"Bearer {self._api_key_override}"
            kwargs["extra_headers"] = headers

        fmt_tools, fmt_tool_choice = self._format_tools(tools, tool_choice)

        if fmt_tools:
            kwargs["tools"] = fmt_tools

        if fmt_tool_choice is not None:
            kwargs["tool_choice"] = fmt_tool_choice

        start_datetime = datetime.now()
        response = await self._request_with_retry_on_auth(kwargs)
        if self.stream:
            return self._parse_stream_response(start_datetime, response)

        return self._parse_completion_response(start_datetime, response)

    async def _request_with_retry_on_auth(
        self,
        kwargs: dict[str, Any],
    ) -> Any:
        """Send the request; on a ``invalid_api_key`` 401, force-refresh the
        key and retry once.

        Refresh/retry only happens when a refresh callback is installed
        (middleware).  If the forced refresh fails to yield a new key, the
        credential is marked as expired (via ``_auth_invalidate_callback``)
        so the *next* call refreshes lazily, and the original 401 is
        surfaced.
        """
        try:
            return await self.client.chat.completions.create(**kwargs)
        except Exception as exc:
            if not self._is_invalid_key_error(exc):
                raise

            if self._refresh_key_callback is None:
                # No refresh capability (model called outside middleware) —
                # surface the 401 as-is.
                logger.warning(
                    "ELLM 401 with no refresh callback installed; "
                    "key not refreshed",
                )
                raise

            try:
                new_key = await self._refresh_key_callback()
            except Exception as refresh_exc:  # noqa: BLE001
                await self._mark_refresh_failed(refresh_exc)
                raise

            # Only retry once when a genuinely new key was obtained; a
            # fallback to the old key would just 401 again.
            if new_key and new_key != self._api_key_override:
                self._api_key_override = new_key
                headers = dict(kwargs.pop("extra_headers", None) or {})
                headers["Authorization"] = f"Bearer {new_key}"
                kwargs["extra_headers"] = headers
                logger.info(
                    "ELLM 401: refreshed key and retrying once "
                    "(credential=%s)",
                    getattr(self.credential, "id", None),
                )
                return await self.client.chat.completions.create(**kwargs)

            # Refresh did not yield a new key — mark expired and surface.
            await self._mark_refresh_failed(None)
            raise

    async def _mark_refresh_failed(self, cause: BaseException | None) -> None:
        """Best-effort mark the credential's key as expired after a failed
        forced refresh, so the next call refreshes it lazily.  Failures are
        swallowed with a warning."""
        if self._auth_invalidate_callback is None:
            return
        try:
            await self._auth_invalidate_callback()
            logger.info(
                "ELLM key invalidated after failed 401 refresh "
                "(credential=%s, cause=%s)",
                getattr(self.credential, "id", None),
                cause,
            )
        except Exception as invalidate_exc:  # noqa: BLE001
            logger.warning(
                "ELLM key invalidation failed after 401 "
                "(error=%s)",
                invalidate_exc,
            )

    async def _parse_stream_response(
        self,
        start_datetime: datetime,
        response: AsyncStream,
    ) -> AsyncGenerator[ChatResponse, None]:
        """Parse the ELLM streaming response.

        When :attr:`inject_think_tag` is enabled, a ``<think>`` tag is
        prepended to the first non-empty text delta (empty deltas are
        skipped, so the tag always lands on real content).

        Args:
            start_datetime (`datetime`):
                The start datetime of the response generation.
            response (`AsyncStream`):
                The OpenAI-compatible async stream object.

        Yields:
            `ChatResponse`:
                Incremental ``ChatResponse`` objects with ``is_last=False``
                followed by a final one with ``is_last=True``.
        """
        usage = None
        response_id: str = _generate_id()
        text_id: str = _generate_id()
        thinking_id: str = _generate_id()
        # The mapping from index to tool call id
        tool_call_mapping: dict = OrderedDict()
        # Whether the <think> tag has been injected into the first
        # non-empty text delta
        _think_injected = False

        async with response as stream:
            async for chunk in stream:
                delta_res = ChatResponse(
                    content=[],
                    is_last=False,
                    id=response_id,
                )

                # Update the response ID if exists
                response_id = getattr(chunk, "id", None) or response_id
                delta_res.id = response_id

                if chunk.usage:
                    u = chunk.usage
                    usage = ChatUsage(
                        input_tokens=u.prompt_tokens,
                        output_tokens=u.completion_tokens,
                        time=(datetime.now() - start_datetime).total_seconds(),
                        cache_input_tokens=getattr(
                            u,
                            "prompt_cache_hit_tokens",
                            0,
                        ),
                    )

                if not chunk.choices:
                    # The gateway may emit a trailing usage-only chunk with
                    # no choices; forward it as an empty-content delta so
                    # the base class ``__call__`` can absorb ``usage`` into
                    # ``acc_res``. The empty delta itself is filtered out
                    # of the surfaced stream by ``_stream``.
                    if usage is not None:
                        delta_res.usage = usage
                        yield delta_res
                    continue

                choice = chunk.choices[0]
                delta = choice.delta

                # Thinking block
                if getattr(delta, "reasoning_content", None):
                    delta_res.append_thinking(
                        block_id=thinking_id,
                        thinking=delta.reasoning_content,
                    )

                # Text
                if getattr(delta, "content", None):
                    delta_text = delta.content
                    if self.inject_think_tag and not _think_injected:
                        delta_text = "<think>" + delta_text
                        _think_injected = True
                    delta_res.append_text(
                        block_id=text_id,
                        text=delta_text,
                    )

                # Tool call
                for tool_call in getattr(delta, "tool_calls", None) or []:
                    index = tool_call.index
                    fn = getattr(tool_call, "function", None)
                    delta_name = getattr(fn, "name", None) if fn else None
                    delta_args = getattr(fn, "arguments", None) if fn else None

                    # Record the id and name in case following deltas
                    # don't provide them
                    if index not in tool_call_mapping:
                        tool_call_mapping[index] = (
                            tool_call.id,
                            delta_name or "unknown",
                        )

                    stored_id, stored_name = tool_call_mapping[index]

                    delta_res.append_tool_call(
                        block_id=tool_call.id or stored_id,
                        name=delta_name or stored_name,
                        input=delta_args or "",
                    )

                if delta_res.content or usage:
                    delta_res.usage = usage
                    yield delta_res

    def _parse_completion_response(
        self,
        start_datetime: datetime,
        response: ChatCompletion,
    ) -> ChatResponse:
        """Parse the ELLM non-streaming response.

        Args:
            start_datetime (`datetime`):
                The start datetime of the response generation.
            response (`ChatCompletion`):
                The OpenAI-compatible chat completion object.

        Returns:
            `ChatResponse`:
                A single ``ChatResponse`` with ``is_last=True``.
        """
        content_blocks: List[TextBlock | ToolCallBlock | ThinkingBlock] = []

        if response.choices:
            choice = response.choices[0]
            reasoning = getattr(choice.message, "reasoning_content", None)
            if isinstance(reasoning, str) and reasoning:
                content_blocks.append(ThinkingBlock(thinking=reasoning))

            if choice.message.content:
                content_blocks.append(TextBlock(text=choice.message.content))

            for tool_call in choice.message.tool_calls or []:
                content_blocks.append(
                    ToolCallBlock(
                        id=tool_call.id,
                        name=tool_call.function.name,
                        input=tool_call.function.arguments,
                    ),
                )

        usage = None
        if response.usage:
            u = response.usage
            usage = ChatUsage(
                input_tokens=u.prompt_tokens,
                output_tokens=u.completion_tokens,
                time=(datetime.now() - start_datetime).total_seconds(),
                cache_input_tokens=getattr(
                    u,
                    "prompt_cache_hit_tokens",
                    0,
                ),
            )

        resp_kwargs: dict[str, Any] = {
            "content": content_blocks,
            "is_last": True,
            "usage": usage,
        }
        response_id = getattr(response, "id", None)
        if response_id:
            resp_kwargs["id"] = response_id

        return ChatResponse(**resp_kwargs)

    def _format_tools(
        self,
        tools: list[dict] | None,
        tool_choice: ToolChoice | None,
    ) -> tuple[list[dict] | None, str | dict | None]:
        """Validate, filter, and format tools and tool_choice for the ELLM
        API.

        When ``tool_choice.tools`` is specified the schemas list is filtered
        to only those tools. When ``tool_choice.mode`` is a specific tool name
        (str) the model is forced to call exactly that tool without needing to
        filter the list, preserving prompt-cache efficiency.

        Args:
            tools (`list[dict] | None`, optional):
                The raw tool schemas.
            tool_choice (`ToolChoice | None`, optional):
                The tool choice configuration.

        Returns:
            `tuple[list[dict] | None, str | dict | None]`:
                A tuple of (formatted_tools, formatted_tool_choice).
        """
        if tool_choice and tools:
            self._validate_tool_choice(tool_choice, tools)
            if tool_choice.tools:
                allowed = set(tool_choice.tools)
                tools = [t for t in tools if t["function"]["name"] in allowed]

        if not tool_choice:
            return tools, None

        mode = tool_choice.mode

        if mode not in _TOOL_CHOICE_LITERAL_MODES:
            return tools, {"type": "function", "function": {"name": mode}}

        return tools, mode

__all__ = ["EllmChatModel"]
