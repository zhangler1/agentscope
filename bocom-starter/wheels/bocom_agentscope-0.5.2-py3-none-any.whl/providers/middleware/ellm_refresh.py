# -*- coding: utf-8 -*-
"""ELLM key-refresh agent middleware.

每次模型调用前，通过 :class:`EllmKeyRefresher` 惰性检查/刷新 ELLM
apikey（过期判定 + ``MessageBus.acquire_lock`` 并发防抖 + 失败回落），
再用 ``EllmChatModel.set_api_key`` 把新鲜 key 注入到当前模型实例的
请求头（``Authorization: Bearer <key>``）。``<think>`` 注入由模型构造
参数 ``inject_think_tag`` 决定，本中间件不再查询任何 Redis 模型配置。
不换类、不重建 client，模型调用链保持不变。

挂载方式::

    from providers.middleware.ellm_refresh import build_ellm_refresh_middleware

    app = create_app(
        ...,
        extra_agent_middlewares=build_ellm_refresh_middleware(storage, message_bus),
    )
"""

from __future__ import annotations

from typing import Any, AsyncGenerator

try:
    from agentscope.middleware import MiddlewareBase
except ImportError:  # pragma: no cover — offline syntax fallback
    class MiddlewareBase:  # type: ignore
        """Fallback MiddlewareBase for syntax checking."""

        _is_agent_middleware = True

        def is_implemented(self, hook_name: str) -> bool:
            base = getattr(MiddlewareBase, hook_name, None)
            sub = getattr(type(self), hook_name, None)
            return base is not sub

        async def list_tools(self) -> list:
            return []

        async def get_middleware_key(self) -> str:
            return self.__class__.__name__

MiddlewareBase._is_agent_middleware = True  # type: ignore[attr-defined]

# 与 SDK 共用同一个 logger（名为 "as"）：格式/级别与 agentscope 内部一致。
from agentscope import logger  # noqa: E402

from providers.ellm_chat_model import EllmChatModel  # noqa: E402
from providers.ellm_key import EllmKeyRefresher  # noqa: E402


class EllmKeyRefreshMiddleware(MiddlewareBase):
    """每次模型调用前把刷新后的 ELLM apikey 注入模型请求头。

    - 非 :class:`EllmChatModel` 模型直接透传，不做任何处理；
    - :class:`EllmChatModel` 模型：``EllmKeyRefresher`` 惰性刷新 →
      ``set_api_key`` 注入；并注入 401 回调：强制刷新 key 并重试当前
      调用一次，刷新失败则标记凭证 key 过期。
    """

    def __init__(
        self,
        storage: Any,
        message_bus: Any,
        user_id: str,
        refresh_ahead_secs: float = 300.0,
    ) -> None:
        self._refresher = EllmKeyRefresher(
            storage,
            message_bus,
            user_id,
            refresh_ahead_secs=refresh_ahead_secs,
        )

    async def on_model_call(
        self,
        agent: Any,
        input_kwargs: dict,
        next_handler: Any,
    ) -> Any:
        current_model = input_kwargs.get("current_model")

        if isinstance(current_model, EllmChatModel):
            credential_id = getattr(
                getattr(current_model, "credential", None),
                "id",
                None,
            )
            if credential_id:
                key, _ = await self._refresher.ensure_fresh_key(
                    credential_id,
                )
                current_model.set_api_key(key)
                # 401 时的行为：
                #   1) 强制刷新 key（force_refresh_key，锁保护）并用新 key
                #      重试当前调用一次；
                #   2) 若强制刷新失败（未拿到新 key），回调把该凭证的 key
                #      置为过期（下一次使用该凭证的调用走惰性刷新）。
                # 两个回调闭包都绑定本次 credential_id，避免并发串号。
                current_model.set_refresh_key_callback(
                    lambda: self._refresher.force_refresh_key(
                        credential_id,
                    ),
                )
                current_model.set_auth_invalidate_callback(
                    lambda: self._refresher.invalidate_key(credential_id),
                )
                logger.debug(
                    "injected refreshed ELLM key (user=%s, credential=%s)",
                    self._refresher.user_id,
                    credential_id,
                )

        return await next_handler(**input_kwargs)


def build_ellm_refresh_middleware(
    storage: Any,
    message_bus: Any,
    refresh_ahead_secs: float = 300.0,
) -> Any:
    """构造 ``AgentMiddlewareFactory``，供 ``create_app(extra_agent_middlewares=...)`` 使用。

    Args:
        storage: StorageBase 实例（bocom-starter main.py 已持有）。
        message_bus: MessageBus 实例。
        refresh_ahead_secs: ELLM key 提前刷新窗口（秒），非必填，
            默认 300.0（key 过期前 300s 提前刷新）。

    Returns:
        ``AgentMiddlewareFactory`` —— ``async (user_id, agent_id, session_id)
        -> list[MiddlewareBase]``。
    """

    async def factory(
        user_id: str,
        agent_id: str,
        session_id: str,
    ) -> list:
        del agent_id, session_id
        return [
            EllmKeyRefreshMiddleware(
                storage,
                message_bus,
                user_id,
                refresh_ahead_secs=refresh_ahead_secs,
            )
        ]

    return factory

__all__ = ["EllmKeyRefreshMiddleware", "build_ellm_refresh_middleware"]
